# API Reference

## Core Classes

### GameManager
Main singleton that orchestrates the entire experience.

**Methods:**
- `StartBookExperience()`: Begins the book experience
- `Instance`: Static singleton instance

### SceneManager
Handles scene loading and transitions.

**Methods:**
- `LoadFirstScene()`: Loads the first scene
- `LoadNextScene()`: Transitions to next scene
- `LoadScene(int sceneIndex)`: Loads specific scene

### ProgressionManager
Tracks and manages player progress.

**Methods:**
- `CompleteScene(int sceneIndex)`: Marks scene as completed
- `IsSceneCompleted(int sceneIndex)`: Checks if scene is completed
- `GetOverallProgress()`: Returns completion percentage

## Events

### Scene Events
- `OnSceneLoaded`: Fired when a scene loads
- `OnSceneCompleted`: Fired when a scene is completed
- `OnBookCompleted`: Fired when entire book is finished

### Interaction Events
- `OnInteractionStart`: User begins interaction
- `OnInteractionComplete`: User completes interaction

## Configuration

### GameConfig
ScriptableObject containing game configuration:
- Total scenes count
- Platform settings
- Performance targets
- Accessibility options
