using UnityEngine;
using System.Collections.Generic;

namespace BookToGame.Core
{
    /// <summary>
    /// Main game manager that orchestrates the entire book-to-game experience
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        [Header("Game Configuration")]
        public GameConfig gameConfig;
        
        [Header("Managers")]
        public SceneManager sceneManager;
        public ProgressionManager progressionManager;
        
        private static GameManager _instance;
        public static GameManager Instance => _instance;
        
        void Awake()
        {
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }
            
            _instance = this;
            DontDestroyOnLoad(gameObject);
            
            InitializeGame();
        }
        
        private void InitializeGame()
        {
            // Load game configuration
            LoadGameConfig();
            
            // Initialize managers
            sceneManager?.Initialize();
            progressionManager?.Initialize();
            
            Debug.Log("BookToGame initialized successfully");
        }
        
        private void LoadGameConfig()
        {
            if (gameConfig == null)
            {
                gameConfig = Resources.Load<GameConfig>("GameConfig");
            }
        }
        
        public void StartBookExperience()
        {
            sceneManager.LoadFirstScene();
        }
    }
}