using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

namespace BookToGame.Core
{
    /// <summary>
    /// Manages scene transitions and loading for the book experience
    /// </summary>
    public class SceneManager : MonoBehaviour
    {
        [Header("Scene Configuration")]
        public int totalScenes = 5;
        private int currentSceneIndex = 0;
        
        public void Initialize()
        {
            Debug.Log($"SceneManager initialized with {totalScenes} scenes");
        }
        
        public void LoadFirstScene()
        {
            LoadScene(0);
        }
        
        public void LoadNextScene()
        {
            if (currentSceneIndex < totalScenes - 1)
            {
                LoadScene(currentSceneIndex + 1);
            }
            else
            {
                OnBookComplete();
            }
        }
        
        public void LoadScene(int sceneIndex)
        {
            if (sceneIndex >= 0 && sceneIndex < totalScenes)
            {
                currentSceneIndex = sceneIndex;
                StartCoroutine(LoadSceneAsync(sceneIndex));
            }
        }
        
        private IEnumerator LoadSceneAsync(int sceneIndex)
        {
            // Show loading screen
            yield return new WaitForSeconds(0.1f);
            
            // Load scene
            AsyncOperation asyncLoad = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync($"Scene{sceneIndex:000}");
            
            while (!asyncLoad.isDone)
            {
                yield return null;
            }
            
            Debug.Log($"Loaded scene {sceneIndex}");
        }
        
        private void OnBookComplete()
        {
            Debug.Log("Book experience completed!");
            // Handle book completion
        }
    }
}