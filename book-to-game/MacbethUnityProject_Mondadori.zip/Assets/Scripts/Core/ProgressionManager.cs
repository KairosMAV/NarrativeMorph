using UnityEngine;
using System.Collections.Generic;

namespace BookToGame.Core
{
    /// <summary>
    /// Manages player progression through the book experience
    /// </summary>
    public class ProgressionManager : MonoBehaviour
    {
        [Header("Progression Data")]
        public PlayerProgressData progressData;
        
        private List<bool> sceneCompletions = new List<bool>();
        
        public void Initialize()
        {
            LoadProgressData();
            Debug.Log("ProgressionManager initialized");
        }
        
        public void CompleteScene(int sceneIndex)
        {
            if (sceneIndex >= 0 && sceneIndex < sceneCompletions.Count)
            {
                sceneCompletions[sceneIndex] = true;
                SaveProgressData();
                Debug.Log($"Scene {sceneIndex} completed");
            }
        }
        
        public bool IsSceneCompleted(int sceneIndex)
        {
            return sceneIndex >= 0 && sceneIndex < sceneCompletions.Count && sceneCompletions[sceneIndex];
        }
        
        public float GetOverallProgress()
        {
            int completedScenes = 0;
            foreach (bool completed in sceneCompletions)
            {
                if (completed) completedScenes++;
            }
            return (float)completedScenes / sceneCompletions.Count;
        }
        
        private void LoadProgressData()
        {
            // Load from PlayerPrefs or save file
            string savedData = PlayerPrefs.GetString("BookProgress", "");
            if (!string.IsNullOrEmpty(savedData))
            {
                // Parse saved data
            }
            else
            {
                // Initialize new progress
                InitializeNewProgress();
            }
        }
        
        private void InitializeNewProgress()
        {
            sceneCompletions.Clear();
            int totalScenes = GameManager.Instance.gameConfig.totalScenes;
            for (int i = 0; i < totalScenes; i++)
            {
                sceneCompletions.Add(false);
            }
        }
        
        private void SaveProgressData()
        {
            // Save to PlayerPrefs or save file
            string dataToSave = JsonUtility.ToJson(sceneCompletions);
            PlayerPrefs.SetString("BookProgress", dataToSave);
            PlayerPrefs.Save();
        }
    }
}